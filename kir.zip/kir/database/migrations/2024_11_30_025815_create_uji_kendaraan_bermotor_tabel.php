<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('uji_kendaraan_bermotor', function (Blueprint $table) {
            $table->id(); // ID utama untuk tabel kendaraan
            $table->unsignedBigInteger('id_identitas_pemilik'); // Foreign key
            $table->string('nomor_uji', 161);
            $table->string('no_kendaraan', 161);
            $table->date('tanggal_srut');
            $table->string('nomor_registrasi', 161);
            $table->timestamps();

            // Tambahkan foreign key ke tabel uji_identitas_pemilik
            $table->foreign('id_identitas_pemilik')
                ->references('id') // Sesuaikan dengan primary key dari tabel uji_identitas_pemilik
                ->on('uji_identitas_pemilik')
                ->onDelete('cascade'); // Jika data pemilik dihapus, data terkait juga dihapus
        });
    }

    /**
     * Reverse the migrations.
     */
   public function down(): void
    {
        Schema::dropIfExists('uji_identitas_bermotor');
    }
};