<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('spesifikasi_teknis_tabel', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_identitas_pemilik'); // Foreign key
            $table->string('jenis_kendaraan');
            $table->string('merk',161);
            $table->string('tipe_kendaraan',161);
            $table->year('tahun_perakitan');
            $table->string('bahan_bakar');
            $table->bigInteger('isi_silinder');
            $table->bigInteger('daya_motor');
            $table->string('ukuran_ban');
            $table->double('konfigurasi_sumbu', 9, 3);
            $table->bigInteger('panjang_dimensi_utama');
            $table->bigInteger('lebar_dimensi_utama');
            $table->bigInteger('julu_depan');
            $table->bigInteger('julu_belakang');
            $table->timestamps();
            $table->foreign('id_identitas_pemilik')
            ->references('id')
            ->on('uji_identitas_pemilik')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('spesifikasi_teknis_tabel');
    }
};