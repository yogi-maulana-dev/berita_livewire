<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('foto_kendaraan_tabel', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_identitas_pemilik'); // Foreign key
            $table->string('foto_depan');
            $table->string('foto_belakang');
            $table->string('foto_kanan');
            $table->string('foto_kiri');
            $table->timestamps();

            $table->foreign('id_identitas_pemilik')
            ->references('id')
            ->on('uji_identitas_pemilik')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('foto_kendaraan_tabel');
    }
};