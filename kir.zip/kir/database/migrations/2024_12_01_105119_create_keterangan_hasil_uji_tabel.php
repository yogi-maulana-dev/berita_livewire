<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('keterangan_hasil_uji_tabel', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_identitas_pemilik');
            $table->string('hasil_uji');
            $table->date('masa_berlaku_uji_berkala');
            $table->string('nama_petugas_penguji');
            $table->string('nrp',160);
            $table->string('nama_kepala_dinas');
            $table->string('pangkat_kepala_dinas');
            $table->decimal('nip_kepala_dinas');
            $table->string('unit_pelaksanaan_teknis_daerah_pengujian');
            $table->timestamps();
            
             $table->foreign('id_identitas_pemilik')
            ->references('id')
            ->on('uji_identitas_pemilik')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('keterangan_hasil_uji_tabel');
    }
};