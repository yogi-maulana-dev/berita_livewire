<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('hasil_uji_tabel', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_identitas_pemilik');
            $table->bigInteger('rem_utama');
            $table->double('rem_utama_sumbu1');
            $table->double('rem_utama_sumbu2');
            $table->double('rem_utama_sumbu3');
            $table->double('rem_utama_sumbu4');
            $table->bigInteger('lampu_utama_kanan');
            $table->bigInteger('lampung_utama_kiri');
            $table->double('lampu_utama_penyimpangan_kanan');
            $table->double('lampu_utama_penyimpangan_kiri');
            $table->timestamps();

            $table->foreign('id_identitas_pemilik')
            ->references('id')
            ->on('uji_identitas_pemilik')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('hasil_uji_tabel');
    }
};