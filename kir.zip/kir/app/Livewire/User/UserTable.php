<?php

namespace App\Livewire\User;

use Livewire\Component;
use App\Models\User;
use Livewire\Attributes\On;
use App\Livewire\Forms\User\UserForm;

class UserTable extends Component
{
  public UserForm $form;


    #[On('dispatch-user-create-save')]
    #[On('dispatch-user-create-edit')]
    #[On('dispatch-user-hapus')]


    public function refreshTable()
    {
        // Handle refresh jika diperlukan
        $this->dispatch('refreshTable');
    }



    public function render()
    {
        return view('livewire.user.user-table', [
            'data' => User::get(),
        ]);
    }
}