<?php

namespace App\Livewire\User;

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\User;
use App\Livewire\Forms\User\UserForm;
use App\Livewire\User\UserTable;


class UserEdit extends Component
{
   
    public UserForm $form;
    public $modalUserEdit = false;

     public $showPassword = false;  // Controls the visibility of the password

    #[On('dispatch-user-table-edit')]
    public function setUser(User $id)
    {
        $this->form->setUser($id);
        $this->modalUserEdit = true;
    }

      public function togglePasswordVisibility()
    {
        $this->showPassword = !$this->showPassword;
    }

    public function edit()
    {
        // Validasi form
        $this->form->validate();

        // Panggil update dari form
        $this->form->update();

        // Dispatch notification
        $this->dispatch('notifity', title: 'success', message: 'Selamat anda berhasil');

        // Dispatch event untuk refresh tabel
        $this->dispatch('dispatch-user-create-edit')->to(UserTable::class);
    }

    public function render()
    {
         return view('livewire.user.user-edit', [
            'showPassword' => $this->showPassword,  // Pass showPassword to the view
        ]);
    }

}