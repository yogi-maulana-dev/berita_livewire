<?php

namespace App\Livewire\User;

use App\Livewire\Forms\User\UserForm;
use App\Livewire\User\UserTable;
use Livewire\Component;

class UserCreate extends Component
{
    public UserForm $form;

    public $modalUserCreate = false;

    public function save()
    {
        $this->validate();

        $simpan = $this->form->store();

        is_null($simpan) ? $this->dispatch('notifity', title: 'success', message: 'Selamat anda berhasil') : $this->dispatch('notifity', title: 'failed', message: 'Selamat anda berhasil');
        $this->dispatch('dispatch-user-create-save')->to(UjiTable::class);
    }

    public function render()
    {
        return view('livewire.user.user-create');
    }
}