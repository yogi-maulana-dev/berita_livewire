<?php

namespace App\Livewire\User;

use App\Livewire\Forms\User\UserForm;
use Livewire\Attributes\On;
use Livewire\Component;

class UserIndex extends Component
{
    public UserForm $form;

    public function render()
    {
        return view('livewire.user.user-index');
    }
}