<?php

namespace App\Livewire;

use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;
use PowerComponents\LivewirePowerGrid\Button;
use PowerComponents\LivewirePowerGrid\Column;
use PowerComponents\LivewirePowerGrid\Facades\Filter;
use PowerComponents\LivewirePowerGrid\Facades\PowerGrid;
use PowerComponents\LivewirePowerGrid\Facades\Rule;
use PowerComponents\LivewirePowerGrid\PowerGridComponent;
use PowerComponents\LivewirePowerGrid\PowerGridFields;
use PowerComponents\LivewirePowerGrid\Responsive;

final class UserTable extends PowerGridComponent
{
    public string $tableName = 'users-table';

    public string $sortField = 'id';

    public string $sortDirection = 'desc';

    public function setUp(): array
    {
        $this->showCheckBox();

        return [PowerGrid::header()->showSearchInput(), PowerGrid::footer()->showPerPage()->showRecordCount(), PowerGrid::cache(), PowerGrid::responsive()->fixedColumns('users.name')];
    }

    public function datasource(): Builder
    {
        return User::query();
    }

    public function fields(): PowerGridFields
    {
        return PowerGrid::fields()
            ->add('sequence_number', function ($model, $row) {
                return $row + 1;
            })
            // ->add('id')
            ->add('name')
            ->add('name_lower', fn(User $model) => strtolower(e($model->name)))
            ->add('created_at')
            ->add('created_at_formatted', fn(User $model) => Carbon::parse($model->created_at)->format('d/m/Y H:i:s'));
    }

    public function columns(): array
    {
        return [
            Column::make('No', 'sequence_number')->sortable()->searchable(),

            // Column::make('ID', 'id')->searchable()->sortable(),
            Column::make('Name', 'name')->searchable()->sortable(),
            Column::make('Created at', 'created_at')->hidden(),
            Column::make('Created at', 'created_at_formatted', 'created_at')->searchable(),
            Column::action('Action'),
        ];
    }

    public function filters(): array
    {
        return [Filter::inputText('name'), Filter::datepicker('created_at_formatted', 'created_at')];
    }

    #[\Livewire\Attributes\On('edit')]
    #[\Livewire\Attributes\On('hapus')]
    public function edit($rowId): void
    {
        $this->js('alert(' . $rowId . ')');
    }

    public function actions(User $row): array
    {
        return [
            Button::add('edit')
                ->slot('<i class="ti-heart f_s_14 me-2"></i> Edit: ' . $row->id)
                ->id('edit-' . $row->id)
                ->class('btn btn-md btn-primary')
                ->dispatch('dispatch-user-table-edit', ['id' => $row->id]),
            Button::add('hapus')
                ->slot('<i class="ti-heart f_s_14 me-2"></i> Hapus: ' . $row->id)
                ->id()
                ->class('btn btn-md btn-danger')
                ->dispatch('dispatch-user-table-hapus', [
                    'id' => $row->id,
                    'name' => $row->name,
                ]),
        ];
    }

    /*
    public function actionRules(User $row): array
    {
       return [
            // Hide button edit for ID 1
            Rule::button('edit')
                ->when(fn($row) => $row->id === 1)
                ->hide(),
        ];
    }
    */

    public function template(): ?string
{
    return <<<'HTML'
    <div>
        <style>
            /* Custom CSS for mobile view */
            @media screen and (max-width: 639px) {
                /* Hide all columns except sequence_number and name */
                .power-grid-table td,
                .power-grid-table th {
                    display: none !important;
                }

                /* Show only sequence_number and name columns */
                .power-grid-table td:nth-child(1),
                .power-grid-table td:nth-child(2),
                .power-grid-table th:nth-child(1),
                .power-grid-table th:nth-child(2) {
                    display: table-cell !important;
                }

                /* Hide action buttons */
                .power-grid-button-container,
                td:last-child,
                th:last-child {
                    display: none !important;
                }

                /* Adjust padding */
                .power-grid-table td {
                    padding: 8px !important;
                }
            }

            /* For screens smaller than 300px */
            @media screen and (max-width: 300px) {
                /* Ensure action buttons are hidden */
                .power-grid-button-container,
                .action-column,
                td:last-child,
                th:last-child {
                    display: none !important;
                    width: 0 !important;
                    padding: 0 !important;
                    margin: 0 !important;
                }

                /* Set the width for visible columns */
                .power-grid-table td:nth-child(1) {
                    width: 20% !important;
                }
                .power-grid-table td:nth-child(2) {
                    width: 30% !important;
                }

                /* Ensure headers are displayed and handle overflow properly */
                .power-grid-table th {
                    display: table-cell !important; /* Ensure header cells are shown */
                    width: auto !important; /* Allow header width to adjust */
                    max-width: 100% !important; /* Allow headers to fill the available space */
                    text-overflow: ellipsis;  /* Handle overflow text */
                    overflow: hidden;
                    white-space: nowrap;
                }
            }

            /* General responsive styling */
            .power-grid-table th {
                width: 100%;
                max-width: 312px !important; /* Set the maximum width for headers */
                text-overflow: ellipsis;  /* Handle overflow text */
                overflow: hidden;
                white-space: nowrap;
            }

            /* Adjustments for larger screens if needed */
            @media screen and (min-width: 640px) {
                .power-grid-table th {
                    max-width: 312px !important;
                }
            }
        </style>

        @include('livewire-powergrid::components.table')
    </div>
    HTML;
}


    protected function getListeners()
    {
        return array_merge(parent::getListeners(), [
            'refreshTable' => '$refresh',
            'dispatch-user-create-save' => '$refresh',
        ]);
    }
}