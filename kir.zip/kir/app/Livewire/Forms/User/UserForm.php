<?php

namespace App\Livewire\Forms\User;

use App\Models\User;
use Livewire\Attributes\Validate;
use Livewire\Form;
use Livewire\Attributes\Rule;

class UserForm extends Form
{
    //
     public ?User $user;

    #[Rule('required|min:3', as: 'Name')]
    public $name;

    #[Rule('required|min:3|email|unique:users,email', as: 'Email')]
    public $email;

    protected function messages()
{
    return [
        'email.required' => 'Kolom email wajib diisi.',
        'email.min' => 'Email harus memiliki minimal 3 karakter.',
        'email.email' => 'Format email tidak valid.',
        'email.unique' => 'Email sudah terdaftar, gunakan email lain.',
    ];
}

    public $password; // Tambahkan properti password

    public $id;

    public function setUser(User $user)
    {
        $this->user = $user;

        $this->name = $user->name;
        $this->email = $user->email;
        $this->password = ''; // Kosongkan password ketika di set
    }

    public function store()
    {
        // Create user tanpa menyertakan 'user' field
        User::create($this->except('user'));
        $this->reset();
    }

    public function update()
    {
        // Ambil data untuk update
        $data = $this->except('user');

        // Jika password diubah, hash password-nya
        if (!empty($this->password)) {
            $data['password'] = bcrypt($this->password);
        } else {
            // Jika password tidak diubah, hapus field password dari data
            unset($data['password']);
        }

        // Update data user
        $this->user->update($data);
    }
}