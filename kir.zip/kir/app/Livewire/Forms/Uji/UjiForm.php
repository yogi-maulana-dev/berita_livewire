<?php

namespace App\Livewire\Forms\Uji;

use App\Models\User;
use Livewire\Attributes\Validate;
use Livewire\Form;
use Livewire\Attributes\Rule;

class UjiForm extends Form
{
    public ?User $uji;

    #[Rule('required|min:3', as: 'Name')]
    public $name;

    #[Rule('required|min:3', as: 'Email')]
    public $email;

    public $password; // Tambahkan properti password

    public $id;

    public function setUji(User $uji)
    {
        $this->uji = $uji;

        $this->name = $uji->name;
        $this->email = $uji->email;
        $this->password = ''; // Kosongkan password ketika di set
    }

    public function store()
    {
        // Create user tanpa menyertakan 'user' field
        User::create($this->except('user'));
        $this->reset();
    }

    public function update()
    {
        // Ambil data untuk update
        $data = $this->except('user');

        // Jika password diubah, hash password-nya
        if (!empty($this->password)) {
            $data['password'] = bcrypt($this->password);
        } else {
            // Jika password tidak diubah, hapus field password dari data
            unset($data['password']);
        }

        // Update data user
        $this->uji->update($data);
    }
}