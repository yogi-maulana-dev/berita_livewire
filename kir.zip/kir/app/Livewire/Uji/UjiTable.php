<?php

namespace App\Livewire\Uji;

use App\Livewire\Forms\Uji\UjiForm;
use App\Models\User;
use Livewire\Attributes\On;
use Livewire\Component;

class UjiTable extends Component
{

    public UjiForm $form;
    public $modalUjiCreate = false;
    #[On('dispatch-uji-create-save')]
    #[On('dispatch-uji-create-edit')]
    #[On('dispatch-uji-hapus')]


    public function refreshTable()
    {
        // Handle refresh jika diperlukan
        $this->dispatch('refreshTable');
    }



    public function render()
    {
        return view('livewire.uji.uji-table', [
            'data' => User::get(),
        ]);
    }
}