<?php

namespace App\Livewire\Uji;

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\User;
use App\Livewire\Forms\Uji\UjiForm;
use App\Livewire\Uji\UjiTable;

class UjiEdit extends Component
{
    public UjiForm $form;
    public $modalUjiEdit = false;

    public $showPassword = false; // Controls the visibility of the password
    public $currentStep = 1; // Tracks the current step in the wizard

    #[On('dispatch-uji-table-edit')]
    public function setUji(User $user)
    {
        // Load data from the user to the form
        $this->form->setUji($user);
        $this->modalUjiEdit = true;
        $this->currentStep = 1; // Reset to step 1 when opening the modal
    }

    public function togglePasswordVisibility()
    {
        $this->showPassword = !$this->showPassword;
    }

    public function nextStep()
    {
        // Validate the current step's fields
        if ($this->currentStep === 1) {
            $this->form->validate([
                'name' => 'required|string|max:255',
            ]);
        } elseif ($this->currentStep === 2) {
            $this->form->validate([
                'email' => 'required|email|unique:users,email,' . $this->form->id,
            ]);
        }

        // Move to the next step
        $this->currentStep++;
    }

    public function previousStep()
    {
        // Go back to the previous step
        $this->currentStep--;
    }

    public function edit()
    {
        // Validate final step fields
        $this->form->validate();

        // Update the record in the database
        $this->form->update();

        // Dispatch notification
        $this->dispatch('notifity', title: 'success', message: 'Data berhasil diperbarui.');

        // Refresh table
        $this->dispatch('dispatch-uji-create-edit')->to(UjiTable::class);

        // Close the modal
        $this->modalUjiEdit = false;
    }

    public function render()
    {
        return view('livewire.uji.uji-edit', [
            'showPassword' => $this->showPassword,
        ]);
    }
}