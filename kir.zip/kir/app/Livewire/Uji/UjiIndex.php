<?php

namespace App\Livewire\Uji;

use App\Livewire\Forms\Uji\UjiForm;
use Livewire\Attributes\On;
use Livewire\Component;


class UjiIndex extends Component
{
    public UjiForm $form;
  

    public function render()
    {
        return view('livewire.uji.uji-index');
    }
}