<?php

namespace App\Livewire\Uji;

use Livewire\Component;
use App\Models\User;
use Livewire\Attributes\On;
use Livewire\Attributes\Locked;
use App\Livewire\Uji\UjiTable;

class UjiHapus extends Component
{


    #[Locked]
    public $id;
    #[Locked]
    public $name;

    public $modalUjiHapus = false;

    #[On('dispatch-uji-table-hapus')]
    public function set_uji($id, $name)
    {
        $this->id = $id;
        $this->name = $name;

        $this->modalUjiHapus = true;
    }

    public function hapus()
    {
        $hapus = User::destroy($this->id);

        ($hapus) ? $this->dispatch('notifity', title: 'success', message: 'Selamat anda berhasil Dihapus')
            : $this->dispatch('notifity', title: 'failed', message: 'Selamat anda berhasil');
        $this->modalUjiHapus = false;
        $this->dispatch('dispatch-uji-hapus')->to(UjiTable::class);
    }


    public function render()
    {
        return view('livewire.uji.uji-hapus');
    }
}