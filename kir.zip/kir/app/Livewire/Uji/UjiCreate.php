<?php

namespace App\Livewire\Uji;

use App\Models\FotoKendaraan;
use App\Models\HasilUji;
use App\Models\KeteranganHasilUji;
use App\Models\SpesifikasiTeknis;
use App\Models\UjiIdentitasPemilik;
use Livewire\Component;
use Livewire\WithFileUploads;

class UjiCreate extends Component
{
    use WithFileUploads;
    
    public $modalUjiCreate = false;
    public $currentStep = 1;
    public $form = [
        'identitas_pemilik' => [
            'nama_pemilik' => '',
            'alamat' => '',
            'nomor_kartu' => '',
            'nomor_rfid' => '',
        ],
        'foto_kendaraan' => [
            'foto_depan' => null,
            'foto_belakang' => null,
            'foto_kanan' => null,
            'foto_kiri' => null,
        ],
        'spesifikasi_teknis' => [
            'jenis_kendaraan' => '',
            'merk' => '',
            'tipe_kendaraan' => '',
            'tahun_perakitan' => '',
            'bahan_bakar' => '',
            'isi_silinder' => '',
            'daya_motor' => '',
            'ukuran_ban' => '',
            'konfigurasi_sumbu' => '',
            'panjang_dimensi_utama' => '',
            'lebar_dimensi_utama' => '',
            'julu_depan' => '',
            'julu_belakang' => '',
        ],
        'hasil_uji' => [
            'rem_utama' => '',
            'rem_utama_sumbu1' => '',
            'rem_utama_sumbu2' => '',
            'rem_utama_sumbu3' => '',
            'rem_utama_sumbu4' => '',
            'lampu_utama_kanan' => '',
            'lampu_utama_kiri' => '',
            'lampu_utama_penyimpangan_kanan' => '',
            'lampu_utama_penyimpangan_kiri' => '',
        ],
        'keterangan_hasil_uji' => [
            'hasil_uji' => '',
            'masa_berlaku_uji_berkala' => '',
            'nama_petugas_penguji' => '',
            'nrp' => '',
            'nama_kepala_dinas' => '',
            'pangkat_kepala_dinas' => '',
            'nip_kepala_dinas' => '',
            'unit_pelaksanaan_teknis_daerah_pengujian' => '',
        ],
    ];
    
    public $successMessage = '';

    public function openModal()
    {
        $this->resetForm();
        $this->modalUjiCreate = true;
    }

    public function closeModal()
    {
        $this->modalUjiCreate = false;
        $this->resetForm();
    }

    public function firstStepSubmit()
    {
        $this->validate([
            'form.identitas_pemilik.nama_pemilik' => 'required|string|max:161',
            'form.identitas_pemilik.alamat' => 'required|string',
            'form.identitas_pemilik.nomor_kartu' => 'required|string|max:161',
            'form.identitas_pemilik.nomor_rfid' => 'required|string|max:161',
        ]);
        
        $this->currentStep = 2;
    }

    public function secondStepSubmit()
    {
        $this->validate([
            'form.foto_kendaraan.foto_depan' => 'required|image|max:1024',
            'form.foto_kendaraan.foto_belakang' => 'required|image|max:1024',
            'form.foto_kendaraan.foto_kanan' => 'required|image|max:1024',
            'form.foto_kendaraan.foto_kiri' => 'required|image|max:1024',
        ]);

        // Store images and get their paths
        $this->form['foto_kendaraan']['foto_depan'] = $this->form['foto_kendaraan']['foto_depan']->store('foto_kendaraan', 'public');
        $this->form['foto_kendaraan']['foto_belakang'] = $this->form['foto_kendaraan']['foto_belakang']->store('foto_kendaraan', 'public');
        $this->form['foto_kendaraan']['foto_kanan'] = $this->form['foto_kendaraan']['foto_kanan']->store('foto_kendaraan', 'public');
        $this->form['foto_kendaraan']['foto_kiri'] = $this->form['foto_kendaraan']['foto_kiri']->store('foto_kendaraan', 'public');
        
        $this->currentStep = 3;
    }

public function thirdStepSubmit()
{
    $this->validate([
        'form.spesifikasi_teknis.jenis_kendaraan' => 'required|string',
        'form.spesifikasi_teknis.merk' => 'required|string|max:161',
        'form.spesifikasi_teknis.tipe_kendaraan' => 'required|string|max:161',
        'form.spesifikasi_teknis.tahun_perakitan' => 'required|integer|min:1900|max:' . date('Y'),
        'form.spesifikasi_teknis.bahan_bakar' => 'required|string',
        'form.spesifikasi_teknis.isi_silinder' => 'required|numeric|min:0',
        'form.spesifikasi_teknis.daya_motor' => 'required|numeric|min:0',
        'form.spesifikasi_teknis.ukuran_ban' => 'required|string',
        'form.spesifikasi_teknis.konfigurasi_sumbu' => 'required|string',
        'form.spesifikasi_teknis.panjang_dimensi_utama' => 'required|numeric|min:0',
        'form.spesifikasi_teknis.lebar_dimensi_utama' => 'required|numeric|min:0',
        'form.spesifikasi_teknis.julu_depan' => 'required|numeric|min:0',
        'form.spesifikasi_teknis.julu_belakang' => 'required|numeric|min:0',
    ]);

    $this->currentStep = 4;
}
// public function fourStepSubmit()
// {
//     $this->validate([
//         'form.spesifikasi_teknis.jenis_kendaraan' => 'required|string',
//         'form.spesifikasi_teknis.merk' => 'required|string|max:161',
//         'form.spesifikasi_teknis.tipe_kendaraan' => 'required|string|max:161',
//         'form.spesifikasi_teknis.tahun_perakitan' => 'required|integer|min:1900|max:' . date('Y'),
//         'form.spesifikasi_teknis.bahan_bakar' => 'required|string',
//         'form.spesifikasi_teknis.isi_silinder' => 'required|numeric|min:0',
//         'form.spesifikasi_teknis.daya_motor' => 'required|numeric|min:0',
//         'form.spesifikasi_teknis.ukuran_ban' => 'required|string',
//         'form.spesifikasi_teknis.konfigurasi_sumbu' => 'required|string',
//         'form.spesifikasi_teknis.panjang_dimensi_utama' => 'required|numeric|min:0',
//         'form.spesifikasi_teknis.lebar_dimensi_utama' => 'required|numeric|min:0',
//         'form.spesifikasi_teknis.julu_depan' => 'required|numeric|min:0',
//         'form.spesifikasi_teknis.julu_belakang' => 'required|numeric|min:0',
//     ]);

//     $this->currentStep = 5;
// }

// public function thirdStepSubmit()
// {
//     $this->validate([
//         'form.spesifikasi_teknis.isi_silinder' => 'required',
//         'form.spesifikasi_teknis.daya_motor' => 'required',
//         'form.spesifikasi_teknis.ukuran_ban' => 'required',
//         'form.spesifikasi_teknis.konfigurasi_sumbu' => 'required',
//         'form.spesifikasi_teknis.panjang_dimensi_utama' => 'required',
//         'form.spesifikasi_teknis.lebar_dimensi_utama' => 'required',
//         'form.spesifikasi_teknis.julu_depan' => 'required',
//         'form.spesifikasi_teknis.julu_belakang' => 'required',
//     ]);

//     // Lanjutkan ke step berikutnya
//     $this->currentStep = 4;
// }


   public function submitForm()
{
    // Validasi field yang diperlukan
    $this->validate([
        'form.hasil_uji.rem_utama' => 'required|string',
        'form.keterangan_hasil_uji.hasil_uji' => 'required|string',
        'form.keterangan_hasil_uji.masa_berlaku_uji_berkala' => 'required|date',
        'form.keterangan_hasil_uji.nama_petugas_penguji' => 'required|string',
        'form.keterangan_hasil_uji.nrp' => 'required|string|max:50',
        'form.keterangan_hasil_uji.nama_kepala_dinas' => 'required|string|max:161',
        'form.keterangan_hasil_uji.pangkat_kepala_dinas' => 'required|string|max:100',
        'form.keterangan_hasil_uji.nip_kepala_dinas' => 'required|string|digits:18',
        'form.keterangan_hasil_uji.unit_pelaksanaan_teknis_daerah_pengujian' => 'required|string|max:255',
    ]);

    try {
        // Mulai transaksi database
        \DB::beginTransaction();

        // Buat data utama
        $identitasPemilik = UjiIdentitasPemilik::create($this->form['identitas_pemilik']);

        // Tambahkan foreign key ke data terkait
        $this->form['foto_kendaraan']['id_identitas_pemilik'] = $identitasPemilik->id;
        $this->form['spesifikasi_teknis']['id_identitas_pemilik'] = $identitasPemilik->id;
        $this->form['hasil_uji']['id_identitas_pemilik'] = $identitasPemilik->id;
        $this->form['keterangan_hasil_uji']['id_identitas_pemilik'] = $identitasPemilik->id;

        // Simpan data terkait
        FotoKendaraan::create($this->form['foto_kendaraan']);
        SpesifikasiTeknis::create($this->form['spesifikasi_teknis']);
        HasilUji::create($this->form['hasil_uji']);
        KeteranganHasilUji::create($this->form['keterangan_hasil_uji']);

        // Commit transaksi
        \DB::commit();

        // Berikan pesan sukses
        $this->successMessage = 'Data berhasil disimpan!';
        $this->resetForm();
        $this->modalUjiCreate = false;

        // Opsional: Dispatch event atau redirect
        $this->dispatch('uji-created');
    } catch (\Exception $e) {
        // Rollback transaksi jika terjadi error
        \DB::rollBack();

        // Log error untuk debugging
        \Log::error('Error saving uji data: ' . $e->getMessage());

        // Tambahkan pesan error global
        $this->addError('form', 'Gagal menyimpan data: ' . $e->getMessage());
    }
}



    public function back($step)
    {
        $this->currentStep = $step;
    }

    private function resetForm()
    {
        $this->form = [
            'identitas_pemilik' => [
                'nama_pemilik' => '',
                'alamat' => '',
                'nomor_kartu' => '',
                'nomor_rfid' => '',
            ],
            'foto_kendaraan' => [
                'foto_depan' => null,
                'foto_belakang' => null,
                'foto_kanan' => null,
                'foto_kiri' => null,
            ],
            'spesifikasi_teknis' => [
                'jenis_kendaraan' => '',
                'merk' => '',
                'tipe_kendaraan' => '',
                'tahun_perakitan' => '',
                'bahan_bakar' => '',
                'isi_silinder' => '',
                'daya_motor' => '',
                'ukuran_ban' => '',
                'konfigurasi_sumbu' => '',
                'panjang_dimensi_utama' => '',
                'lebar_dimensi_utama' => '',
                'julu_depan' => '',
                'julu_belakang' => '',
            ],
            'hasil_uji' => [
                'rem_utama' => '',
                'rem_utama_sumbu1' => '',
                'rem_utama_sumbu2' => '',
                'rem_utama_sumbu3' => '',
                'rem_utama_sumbu4' => '',
                'lampu_utama_kanan' => '',
                'lampu_utama_kiri' => '',
                'lampu_utama_penyimpangan_kanan' => '',
                'lampu_utama_penyimpangan_kiri' => '',
            ],
            'keterangan_hasil_uji' => [
                'hasil_uji' => '',
                'masa_berlaku_uji_berkala' => '',
                'nama_petugas_penguji' => '',
                'nrp' => '',
                'nama_kepala_dinas' => '',
                'pangkat_kepala_dinas' => '',
                'nip_kepala_dinas' => '',
                'unit_pelaksanaan_teknis_daerah_pengujian' => '',
            ],
        ];
        $this->currentStep = 1;
        $this->successMessage = '';
    }

    public function render()
    {
        return view('livewire.uji.uji-create');
    }
}