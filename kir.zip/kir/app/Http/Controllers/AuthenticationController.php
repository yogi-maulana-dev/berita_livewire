<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserDetailResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class AuthenticationController extends Controller
{

public function login(Request $request)
{

   $request->validate([
    "email" => "required|email",
    "password" => "required",
], [
    "email.required" => "Email wajib diisi.",
    "email.email" => "Email yang dimasukkan tidak valid.",
    "password.required" => "Password wajib diisi.",
]);


    $user = User::where("email", $request->email)->first();

    if (!$user || !Hash::check($request->password, $user->password)) {
        throw ValidationException::withMessages(["email" => ['Email atau password salah']]);
    }

    return response()->json([
        'token' => $user->createToken($request->device_name ?? 'default')->plainTextToken,
        'user' => $user,
    ]);
}


public function logout(Request $request)
{
    // Ambil token akses yang sedang digunakan
    $token = $request->user()->currentAccessToken();

    if ($token) {
        Log::info('Token yang akan dihapus:', [
            'token_id' => $token->id,
            'token_value' => $token->token,
        ]);

        // Hapus token dari tabel personal_access_tokens
        $token->delete();

        return response()->json([
            'success' => true,
            'message' => 'Logout berhasil',
        ], 200);
    }

    return response()->json([
        'success' => false,
        'message' => 'Token tidak ditemukan',
    ], 400);
}

    public function me(Request $request)
    {
        return response()->json(data: Auth::user());
    }

    public function store(Request $request)
    {
        // Validasi input
        $validated = $request->validate([
            'email' => 'required|email|unique:users,email',
            'name' => 'required',
            'password' => 'required|min:8'
        ]);

        // Buat pengguna baru dengan data yang divalidasi
        $user = User::create([
            'email' => $validated['email'],
            'name' => $validated['name'],
            'password' => bcrypt($validated['password']), // Enkripsi kata sandi
        ]);

        // Return UserDetailResource
        return new UserDetailResource($user);
    }

    public function update(Request $request, $id)
    {
        try {
            // Temukan user berdasarkan ID atau lempar error jika tidak ditemukan
            $user = User::findOrFail($id);

            // Validasi input, perhatikan bahwa email unik hanya untuk pengguna lain
            $validated = $request->validate([
                'email' => 'required|email|unique:users,email,' . $user->id,
                'name' => 'required|string|max:255',
                'password' => 'nullable|min:8' // Password bersifat opsional saat update
            ]);

            // Siapkan data yang akan diperbarui
            $dataToUpdate = [
                'email' => $validated['email'],
                'name' => $validated['name']
            ];

            // Jika password diisi, enkripsi password baru
            if (!empty($validated['password'])) {
                $dataToUpdate['password'] = bcrypt($validated['password']);
            }

            // Update user dengan data yang sudah divalidasi
            $user->update($dataToUpdate);

            // Return JSON response untuk keberhasilan
            return response()->json([
                'success' => true,
                'message' => 'User berhasil diperbarui.',
                'data' => new UserDetailResource($user)
            ], 200);

        } catch (\Exception $e) {
            // Return JSON response jika terjadi kesalahan
            return response()->json([
                'success' => false,
                'message' => 'User gagal diperbarui.',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    public function destroy($id)
    {
        try {
            // Temukan user berdasarkan ID atau lempar error jika tidak ditemukan
            $user = User::findOrFail($id);

            // Simpan data pengguna yang akan dihapus ke dalam UserDetailResource
            $deletedUserData = new UserDetailResource($user);

            // Hapus pengguna dari database
            $user->delete();

            // Mengembalikan response JSON untuk keberhasilan dengan data pengguna yang telah dihapus
            return response()->json([
                'success' => true,
                'message' => 'User berhasil dihapus.',
                'data' => $deletedUserData
            ], 200);

        } catch (\Exception $e) {
            // Jika terjadi error, kembalikan response JSON error
            return response()->json([
                'success' => false,
                'message' => 'User gagal dihapus.',
                'error' => $e->getMessage()
            ], 500);
        }
    }




}