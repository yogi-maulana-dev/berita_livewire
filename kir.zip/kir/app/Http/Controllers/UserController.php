<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Resources\UserResource;
use App\Http\Resources\UserDetailResource;

class UserController extends Controller
{
    /**
     * Display a listing of users.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $users = User::paginate(10); // Menampilkan data pengguna dengan paginasi
        return UserResource::collection($users);
    }

    public function show($id)
    {
        $users = User::findOrFail($id);
        // return response()->json(['data' => $users]);
        return new UserDetailResource($users);

    }
}