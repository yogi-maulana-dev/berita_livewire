<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HasilUji extends Model
{
    protected $table = 'hasil_uji_tabel';

    protected $fillable = [
        'id_identitas_pemilik',
        'rem_utama',
        'rem_utama_sumbu1',
        'rem_utama_sumbu2',
        'rem_utama_sumbu3',
        'rem_utama_sumbu4',
        'lampu_utama_kanan',
        'lampung_utama_kiri',
        'lampu_utama_penyimpangan_kanan',
        'lampu_utama_penyimpangan_kiri'
    ];

    // Relationship
    public function identitasPemilik()
    {
        return $this->belongsTo(UjiIdentitasPemilik::class, 'id_identitas_pemilik');
    }
}