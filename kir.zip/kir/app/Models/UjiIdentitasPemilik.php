<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UjiIdentitasPemilik extends Model
{
    protected $table = 'uji_identitas_pemilik';

    protected $fillable = [
        'nama_pemilik',
        'alamat',
        'nomor_kartu',
        'nomor_rfid'
    ];

    // Relationships
    public function fotoKendaraan()
    {
        return $this->hasOne(FotoKendaraan::class, 'id_identitas_pemilik');
    }

    public function spesifikasiTeknis()
    {
        return $this->hasOne(SpesifikasiTeknis::class, 'id_identitas_pemilik');
    }

    public function hasilUji()
    {
        return $this->hasOne(HasilUji::class, 'id_identitas_pemilik');
    }

    public function keteranganHasilUji()
    {
        return $this->hasOne(KeteranganHasilUji::class, 'id_identitas_pemilik');
    }
}