<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KeteranganHasilUji extends Model
{
    protected $table = 'keterangan_hasil_uji_tabel';

    protected $fillable = [
        'id_identitas_pemilik',
        'hasil_uji',
        'masa_berlaku_uji_berkala',
        'nama_petugas_penguji',
        'nrp',
        'nama_kepala_dinas',
        'pangkat_kepala_dinas',
        'nip_kepala_dinas',
        'unit_pelaksanaan_teknis_daerah_pengujian'
    ];

    // Relationship
    public function identitasPemilik()
    {
        return $this->belongsTo(UjiIdentitasPemilik::class, 'id_identitas_pemilik');
    }
}