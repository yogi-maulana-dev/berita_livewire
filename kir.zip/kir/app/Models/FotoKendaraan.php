<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FotoKendaraan extends Model
{
    protected $table = 'foto_kendaraan_tabel';

    protected $fillable = [
        'id_identitas_pemilik',
        'foto_depan',
        'foto_belakang',
        'foto_kanan',
        'foto_kiri'
    ];

    // Relationship
    public function identitasPemilik()
    {
        return $this->belongsTo(UjiIdentitasPemilik::class, 'id_identitas_pemilik');
    }
}