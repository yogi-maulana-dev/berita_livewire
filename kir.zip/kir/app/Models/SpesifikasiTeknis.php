<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpesifikasiTeknis extends Model
{
    protected $table = 'spesifikasi_teknis_tabel';

    protected $fillable = [
        'id_identitas_pemilik',
        'jenis_kendaraan',
        'merk',
        'tipe_kendaraan',
        'tahun_perakitan',
        'bahan_bakar',
        'isi_silinder',
        'daya_motor',
        'ukuran_ban',
        'konfigurasi_sumbu',
        'panjang_dimensi_utama',
        'lebar_dimensi_utama',
        'julu_depan',
        'julu_belakang'
    ];

    // Relationship
    public function identitasPemilik()
    {
        return $this->belongsTo(UjiIdentitasPemilik::class, 'id_identitas_pemilik');
    }
}