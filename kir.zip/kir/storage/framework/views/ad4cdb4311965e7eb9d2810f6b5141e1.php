 
 <textarea
     <?php echo e($attributes->merge([
         'class' =>
             'block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50',
     ])); ?>><?php echo e($slot); ?></textarea>
<?php /**PATH D:\gituhub\New folder (4)\kir\resources\views/components/textarea.blade.php ENDPATH**/ ?>