<div>
    <div class="main_content_iner">
        <div class="p-0 container-fluid">
            <div class="row justify-content-center">
                <!-- Main Content Card -->
                <div class="col-lg-12">
                    <div class="white_card card_height_100 mb_30">
                        <!-- Card Header -->
                        <div class="white_card_header">
                            <div class="m-0 box_header">
                                <div class="main-title">
                                    <h3 class="m-0">Data tablex</h3>
                                </div>
                            </div>
                        </div>

                        <!-- Card Body -->
                        <div class="white_card_body">
                            <div class="QA_section">
                                <!-- Table Header Section -->
                                <div class="white_box_tittle list_header">
                                    <h4>Tablexxxx</h4>
                                    <div class="box_right d-flex lms_block">
                                        <div class="flex items-center justify-between w-full py-3 md:w-auto">
                                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.user-create', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-38171694-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Table Components -->
                                <div class="table_components">
                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.user-hapus', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-38171694-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.user-edit', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-38171694-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.user-table', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-38171694-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\gituhub\New folder (4)\kir\resources\views/livewire/user/user-index.blade.php ENDPATH**/ ?>