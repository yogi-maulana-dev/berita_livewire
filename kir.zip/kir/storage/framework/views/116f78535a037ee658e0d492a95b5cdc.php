<div>
    
    <div class="w-full mt-2" wire:init="$refresh">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user-table', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3029352731-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</div>
<?php /**PATH D:\gituhub\New folder (4)\kir\resources\views/livewire/user/user-table.blade.php ENDPATH**/ ?>