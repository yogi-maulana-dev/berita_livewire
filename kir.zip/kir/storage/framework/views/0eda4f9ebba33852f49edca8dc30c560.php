<?php echo e($slot); ?>

<?php /**PATH D:\gituhub\New folder (4)\kir\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>