<nav class="sidebar vertical-scroll ps-container ps-theme-default ps-active-y">
    <div class="text-center logo">
        <a href="index.html">
            <img src="{{ asset('img/logop.jpg') }}" alt="Logo" class="img-fluid">
        </a>
        <div class="sidebar_close_icon d-lg-none">
            <i class="ti-close"></i>
        </div>
    </div>

    <ul id="sidebar_menu">
        <li>
            <x-nav-link :active="request()->routeIs('dashboard')" href="{{ route('dashboard') }}">
                <div class="icon_menu">
                    <img src="{{ Vite::asset('resources/img/menu-icon/2.svg') }}" alt="Uji Icon">
                </div>
                <span>{{ __('Dashboard') }}</span>
            </x-nav-link>
        </li>

        <li>
            <x-nav-link href="{{ route('user') }}" :active="request()->routeIs('user')" aria-expanded="false">
                <div class="icon_menu">
                    <img src="{{ Vite::asset('resources/img/menu-icon/2.svg') }}" alt="User Icon">
                </div>
                <span>User</span>
            </x-nav-link>
        </li>
        <li>
            <x-nav-link href="{{ route('uji') }}" :active="request()->routeIs('uji')" aria-expanded="false">
                <div class="icon_menu">
                    <img src="{{ Vite::asset('resources/img/menu-icon/4.svg') }}" alt="Uji Icon">
                </div>
                <span>Uji Kendataan</span>
            </x-nav-link>
        </li>


    </ul>
</nav>
