<div>
    {{-- Nothing in the world is as soft and yielding as water. --}}

    <x-button @click="$wire.set('modalUserCreate', true)">
        Buat Uji
    </x-button>

    <x-dialog-modal wire:model.live="modalUserCreate" submit="save">
        <x-slot name="title">
            Uji Tambah
        </x-slot>

        <x-slot name="content">
            <div class="grid grid-cols-12 gap-4">
                <div class="col-span-12">
                    <x-label for="form_name" value="Name Uji" />
                    <x-input wire:model="form.name" id="form_name" type="text" class="w-full mt-1" required
                        autocomplete="name" />
                    <x-input-error for="form.name" class="text-sm text-danger mt-1" />
                </div>

                <div class="col-span-12">
                    <x-label for="form_email" value="Email Uji" />
                    <x-input wire:model="form.email" id="form_email" type="text" class="w-full mt-1" required
                        autocomplete="email" />
                    <x-input-error for="form.email" class="text-sm text-danger mt-1" />
                </div>

                <div class="col-span-12">
                    <x-label for="form_password" value="Password Uji" />
                    <x-input wire:model="form.password" id="form_password" type="password" class="w-full mt-1" required
                        autocomplete="new-password" />
                    <x-input-error for="form.password" class="text-sm text-danger mt-1" />
                </div>
            </div>
        </x-slot>

        <x-slot name="footer">
            <x-secondary-button @click="$wire.set('modalUserCreate', false)" wire:loading.attr="disabled">
                Batal
            </x-secondary-button>

            <x-button class="ms-3" wire:loading.attr="disabled">
                Simpan
            </x-button>
        </x-slot>
    </x-dialog-modal>
</div>
