<div>
    {{-- Do your work, then step back. --}}
    <div class="w-full mt-2" wire:init="$refresh">
        <livewire:user-table />
    </div>
</div>
