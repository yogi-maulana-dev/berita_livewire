<div>
    <!-- Dialog Modal -->
    <x-dialog-modal wire:model.live="modalUserEdit" submit="edit">
        <x-slot name="title">
            Uji Edit
        </x-slot>

        <x-slot name="content">
            <div class="grid grid-cols-12 gap-4">
                <!-- Name Field -->
                <div class="col-span-12">
                    <x-label for="form.name" value="Name Uji" />
                    <x-input wire:model='form.name' id="form.name" type="text" class="w-full mt-1" required
                        autocomplete="form.name" />
                    <x-input-error for="form.name" class="mt-1" />
                </div>

                <!-- Email Field -->
                <div class="col-span-12">
                    <x-label for="form.email" value="Email Uji" />
                    <x-input wire:model='form.email' id="form.email" type="text" class="w-full mt-1" required
                        autocomplete="form.email" />
                    <x-input-error for="form.email" class="mt-1" />
                </div>

                <!-- Password Field (Optional) -->
                <div class="col-span-12">
                    <x-label for="form.password" value="Password Baru (Opsional)" />
                    <div class="relative">
                        <!-- Password Input -->
                        <x-input wire:model.defer="form.password" id="form.password"
                            type="{{ $showPassword ? 'text' : 'password' }}" class="w-full pr-10 mt-1"
                            autocomplete="new-password" />

                        <!-- Toggle Button to Show/Hide Password -->
                        <button type="button" class="absolute mt-2 text-gray-500 right-2 top-2"
                            wire:click="$toggle('showPassword')">
                            <span>{{ $showPassword ? 'Sembunyikan' : 'Lihat' }}</span>
                        </button>
                    </div>
                    <x-input-error for="form.password" class="mt-1" />
                </div>
            </div>
        </x-slot>

        <!-- Modal Footer with Buttons -->
        <x-slot name="footer">
            <x-secondary-button @click="$wire.set('modalUserEdit', false)" wire:loading.attr="disabled">
                Batal
            </x-secondary-button>

            <x-button class="ms-3" wire:loading.attr="disabled">
                Update
            </x-button>
        </x-slot>
    </x-dialog-modal>
</div>
