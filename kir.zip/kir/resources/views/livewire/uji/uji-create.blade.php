<div>
    <x-button @click="$wire.set('modalUjiCreate', true)">
        Buat Uji
    </x-button>

    <x-dialog-modal wire:model.live="modalUjiCreate">
        <x-slot name="title">
            Tambah Uji
        </x-slot>

        <x-slot name="content">
            <div class="stepwizard">
                <div class="stepwizard-row setup-panel">
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 1 ? 'btn-primary' : 'btn-default' }}"
                            disabled>1</button>
                        <p>Identitas Pemilik</p>
                    </div>
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 2 ? 'btn-primary' : 'btn-default' }}"
                            disabled>2</button>
                        <p>Foto Kendaraan</p>
                    </div>
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 3 ? 'btn-primary' : 'btn-default' }}"
                            disabled>3</button>
                        <p>Spesifikasi Teknis</p>
                    </div>
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 4 ? 'btn-primary' : 'btn-default' }}"
                            disabled>4</button>
                        <p>Hasil Uji</p>
                    </div>
                </div>
                @if ($errors->has('form'))
                    <div class="alert alert-danger">
                        <strong>Error:</strong> {{ $errors->first('form') }}
                    </div>
                @endif
            </div>



            @if ($currentStep == 1)
                <!-- Step 1: Identitas Pemilik -->
                <div class="container">
                    <div class="row g-3 border p-4">
                        <!-- Nama Pemilik -->
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <x-label for="nama_pemilik">Nama Pemilik</x-label>
                                <x-input wire:model="form.identitas_pemilik.nama_pemilik" type="text"
                                    id="nama_pemilik" placeholder="Masukkan nama pemilik" class="w-full" />
                                @error('form.identitas_pemilik.nama_pemilik')
                                    <span class="text-danger small">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Nomor Kartu -->
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <x-label for="nomor_kartu">Nomor Kartu</x-label>
                                <x-input wire:model="form.identitas_pemilik.nomor_kartu" type="text" id="nomor_kartu"
                                    placeholder="Masukkan nomor kartu" class="w-full" />
                                @error('form.identitas_pemilik.nomor_kartu')
                                    <span class="text-danger small">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Alamat -->
                        <div class="col-12">
                            <div class="mb-3">
                                <x-label for="alamat">Alamat</x-label>
                                <textarea wire:model="form.identitas_pemilik.alamat" id="alamat" placeholder="Masukkan alamat lengkap"
                                    class="w-full"></textarea>
                                @error('form.identitas_pemilik.alamat')
                                    <span class="text-danger small">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Nomor RFID -->
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <x-label for="nomor_rfid">Nomor RFID</x-label>
                                <x-input wire:model="form.identitas_pemilik.nomor_rfid" type="text" id="nomor_rfid"
                                    placeholder="Masukkan nomor RFID" class="w-full" />
                                @error('form.identitas_pemilik.nomor_rfid')
                                    <span class="text-danger small">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Tombol -->
                        <div class="col-12">
                            <div class="d-flex justify-content-end mt-3">
                                <x-button wire:click="firstStepSubmit" type="button" class="btn btn-primary">
                                    Lanjut ke Foto Kendaraan
                                </x-button>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @if ($currentStep == 2)
                <!-- Step 2: Foto Kendaraan -->
                <div class="container">
                    <div class="row g-3 border p-4">
                        <div class="border rounded-lg p-4">
                            <x-label for="foto_depan">Foto Depan</x-label>
                            <input wire:model="form.foto_kendaraan.foto_depan" type="file" id="foto_depan"
                                class="block w-full border-gray-300 rounded-md shadow-sm" />
                            @error('form.foto_kendaraan.foto_depan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="border rounded-lg p-4">
                            <x-label for="foto_belakang">Foto Belakang</x-label>
                            <input wire:model="form.foto_kendaraan.foto_belakang" type="file" id="foto_belakang"
                                class="block w-full border-gray-300 rounded-md shadow-sm" />
                            @error('form.foto_kendaraan.foto_belakang')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="border rounded-lg p-4">
                            <x-label for="foto_kanan">Foto Kanan</x-label>
                            <input wire:model="form.foto_kendaraan.foto_kanan" type="file" id="foto_kanan"
                                class="block w-full border-gray-300 rounded-md shadow-sm" />
                            @error('form.foto_kendaraan.foto_kanan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="border rounded-lg p-4">
                            <x-label for="foto_kiri">Foto Kiri</x-label>
                            <input wire:model="form.foto_kendaraan.foto_kiri" type="file" id="foto_kiri"
                                class="block w-full border-gray-300 rounded-md shadow-sm" />
                            @error('form.foto_kendaraan.foto_kiri')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Tombol -->
                        <div class="col-12">
                            <div class="d-flex justify-content-between gap-3 mt-3">
                                <button class="btn btn-danger" wire:click="back(1)" type="button">
                                    Kembali
                                </button>

                                <button class="btn btn-primary" wire:click="secondStepSubmit" type="button">
                                    Lanjut ke Spesifikasi Teknis
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @if ($currentStep == 3)
                <!-- Step 3: Spesifikasi Teknis -->
                <div class="container">
                    <div class="row g-3 border p-4">
                        <!-- Teknis Lanjutan -->
                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="isi_silinder">Isi Silinder</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.isi_silinder" type="text"
                                id="isi_silinder" placeholder="Masukkan isi silinder" class="w-full" />
                            @error('form.spesifikasi_teknis.isi_silinder')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="daya_motor">Daya Motor</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.daya_motor" type="text"
                                id="daya_motor" placeholder="Masukkan daya motor" class="w-full" />
                            @error('form.spesifikasi_teknis.daya_motor')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="ukuran_ban">Ukuran Ban</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.ukuran_ban" type="text"
                                id="ukuran_ban" placeholder="Masukkan ukuran ban" class="w-full" />
                            @error('form.spesifikasi_teknis.ukuran_ban')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="konfigurasi_sumbu">Konfigurasi Sumbu</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.konfigurasi_sumbu" type="text"
                                id="konfigurasi_sumbu" placeholder="Masukkan konfigurasi sumbu" class="w-full" />
                            @error('form.spesifikasi_teknis.konfigurasi_sumbu')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="panjang_dimensi_utama">Panjang Dimensi Utama</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.panjang_dimensi_utama" type="text"
                                id="panjang_dimensi_utama" placeholder="Masukkan panjang dimensi" class="w-full" />
                            @error('form.spesifikasi_teknis.panjang_dimensi_utama')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="lebar_dimensi_utama">Lebar Dimensi Utama</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.lebar_dimensi_utama" type="text"
                                id="lebar_dimensi_utama" placeholder="Masukkan lebar dimensi" class="w-full" />
                            @error('form.spesifikasi_teknis.lebar_dimensi_utama')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="julu_depan">Julu Depan</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.julu_depan" type="text"
                                id="julu_depan" placeholder="Masukkan julu depan" class="w-full" />
                            @error('form.spesifikasi_teknis.julu_depan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3 col-12 col-md-6">
                            <x-label for="julu_belakang">Julu Belakang</x-label>
                            <x-input wire:model.defer="form.spesifikasi_teknis.julu_belakang" type="text"
                                id="julu_belakang" placeholder="Masukkan julu belakang" class="w-full" />
                            @error('form.spesifikasi_teknis.julu_belakang')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Tombol -->
                        <div class="col-12">
                            <div class="d-flex justify-content-between gap-3 mt-3">
                                <button class="btn btn-danger" wire:click="back(2)" type="button">
                                    Kembali
                                </button>

                                <x-button wire:click="thirdStepSubmit" type="button" class="btn btn-primary">
                                    Lanjut ke Hasil Uji
                                </x-button>
                            </div>
                        </div>
                    </div>
                </div>
            @endif



            @if ($currentStep == 4)
                <div class="container">
                    <div class="row g-3 border p-4">
                        <!-- Tambahan Step: Hasil Uji -->
                        <div class="mb-3">
                            <x-label for="rem_utama">Rem Utama</x-label>
                            <x-input wire:model="form.hasil_uji.rem_utama" type="text" id="rem_utama"
                                placeholder="Masukkan kondisi rem utama" class="w-full" />
                            @error('form.hasil_uji.rem_utama')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="hasil_uji">Hasil Uji</x-label>
                            <select wire:model="form.keterangan_hasil_uji.hasil_uji" id="hasil_uji"
                                class="block w-full border-gray-300 rounded-md shadow-sm">
                                <option value="">Pilih Hasil Uji</option>
                                <option value="lulus">Lulus</option>
                                <option value="tidak_lulus">Tidak Lulus</option>
                            </select>
                            @error('form.keterangan_hasil_uji.hasil_uji')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="masa_berlaku_uji">Masa Berlaku Uji</x-label>
                            <x-input wire:model="form.keterangan_hasil_uji.masa_berlaku_uji_berkala" type="date"
                                id="masa_berlaku_uji" class="w-full" />
                            @error('form.keterangan_hasil_uji.masa_berlaku_uji_berkala')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="nama_petugas">Nama Petugas Penguji</x-label>
                            <x-input wire:model="form.keterangan_hasil_uji.nama_petugas_penguji" type="text"
                                id="nama_petugas" placeholder="Nama Petugas" class="w-full" />
                            @error('form.keterangan_hasil_uji.nama_petugas_penguji')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="nrp">NRP Petugas</x-label>
                            <x-input wire:model="form.keterangan_hasil_uji.nrp" type="text" id="nrp"
                                placeholder="Nomor Registrasi Petugas" class="w-full" />
                            @error('form.keterangan_hasil_uji.nrp')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="nama_kepala_dinas">Nama Kepala Dinas</x-label>
                            <x-input wire:model="form.keterangan_hasil_uji.nama_kepala_dinas" type="text"
                                id="nama_kepala_dinas" placeholder="Nama Kepala Dinas" class="w-full" />
                            @error('form.keterangan_hasil_uji.nama_kepala_dinas')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="pangkat_kepala_dinas">Pangkat Kepala Dinas</x-label>
                            <x-input wire:model="form.keterangan_hasil_uji.pangkat_kepala_dinas" type="text"
                                id="pangkat_kepala_dinas" placeholder="Pangkat Kepala Dinas" class="w-full" />
                            @error('form.keterangan_hasil_uji.pangkat_kepala_dinas')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="nip_kepala_dinas">NIP Kepala Dinas</x-label>
                            <x-input wire:model="form.keterangan_hasil_uji.nip_kepala_dinas" type="text"
                                id="nip_kepala_dinas" placeholder="NIP Kepala Dinas" class="w-full" />
                            @error('form.keterangan_hasil_uji.nip_kepala_dinas')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <x-label for="unit_pelaksanaan">Unit Pelaksanaan Teknis</x-label>
                            <x-input wire:model="form.keterangan_hasil_uji.unit_pelaksanaan_teknis_daerah_pengujian"
                                type="text" id="unit_pelaksanaan" placeholder="Unit Pelaksanaan Teknis"
                                class="w-full" />
                            @error('form.keterangan_hasil_uji.unit_pelaksanaan_teknis_daerah_pengujian')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Tombol -->
                        <div class="col-12">
                            <div class="d-flex justify-content-between gap-3 mt-3">
                                <button class="btn btn-danger" wire:click="back(3)" type="button">
                                    Back
                                </button>

                                <x-button wire:click="submitForm" type="button"
                                    class="bg-green-500 hover:bg-green-600 text-white">
                                    Simpan Data Uji
                                </x-button>
                            </div>
                        </div>
                    </div>
                </div>
            @endif


            <!-- Existing steps remain the same -->
        </x-slot>

        <x-slot name="footer">
            <x-secondary-button @click="$wire.set('modalUjiCreate', false)" wire:loading.attr="disabled">
                Tutup
            </x-secondary-button>
        </x-slot>
    </x-dialog-modal>
</div>
