<div>
    <x-button @click="$wire.set('modalUjiCreate', true)">
        Buat Uji
    </x-button>

    <x-dialog-modal wire:model.live="modalUjiCreate">
        <x-slot name="title">
            Form Wizard - Tambah Uji

            <div class="stepwizard">
                <div class="stepwizard-row setup-panel">
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 1 ? 'btn-primary' : 'btn-default' }}"
                            disabled>1</button>
                        <p>Step 1</p>
                    </div>
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 2 ? 'btn-primary' : 'btn-default' }}"
                            disabled>2</button>
                        <p>Step 2</p>
                    </div>
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 3 ? 'btn-primary' : 'btn-default' }}"
                            disabled>3</button>
                        <p>Step 3</p>
                    </div>
                </div>
            </div>

        </x-slot>

        <x-slot name="content">
            <!-- Step 1 -->
            @if ($currentStep == 1)
                {{--  pisah  --}}

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <x-label for="nama_pemilik">Nama Pemilik</x-label>
                        <x-input wire:model="form.identitas_pemilik.nama_pemilik" type="text" id="nama_pemilik"
                            placeholder="Masukkan nama pemilik" />
                        @error('form.identitas_pemilik.nama_pemilik')
                            <span class="text-red-500 text-sm">{{ $message }}</span>
                        @enderror
                    </div>

                    <div>
                        <x-label for="nomor_kartu">Nomor Kartu</x-label>
                        <x-input wire:model="form.identitas_pemilik.nomor_kartu" type="text" id="nomor_kartu"
                            placeholder="Masukkan nomor kartu" />
                        @error('form.identitas_pemilik.nomor_kartu')
                            <span class="text-red-500 text-sm">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="col-span-2">
                        <x-label for="alamat">Alamat</x-label>
                        <x-textarea wire:model="form.identitas_pemilik.alamat" id="alamat"
                            placeholder="Masukkan alamat lengkap" />
                        @error('form.identitas_pemilik.alamat')
                            <span class="text-red-500 text-sm">{{ $message }}</span>
                        @enderror
                    </div>

                    <div>
                        <x-label for="nomor_rfid">Nomor RFID</x-label>
                        <x-input wire:model="form.identitas_pemilik.nomor_rfid" type="text" id="nomor_rfid"
                            placeholder="Masukkan nomor RFID" />
                        @error('form.identitas_pemilik.nomor_rfid')
                            <span class="text-red-500 text-sm">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="col-span-2 flex justify-end">
                        <x-button wire:click="firstStepSubmit" type="button">
                            Lanjut ke Foto Kendaraan
                        </x-button>
                    </div>
                </div>
                {{--  <x-input-error for="form.name" class="text-sm text-danger mt-1" />  --}}


                {{--  <button class="btn btn-primary mt-3 pull-right" wire:click="firstStepSubmit"
                    type="button">Next</button>  --}}
            @endif

            <!-- Step 2 -->
            @if ($currentStep == 2)
                <div>
                    <h3>Step 2</h3>
                    <x-label for="form_email" value="Email Uji" />
                    <x-input wire:model="form.email" id="form_email" type="email" class="w-full mt-1" required
                        autocomplete="email" />
                    <x-input-error for="form.email" class="text-sm text-danger mt-1" />

                    <button class="btn btn-danger mt-3 pull-right" wire:click="back(1)" type="button">Back</button>
                    <button class="btn btn-primary mt-3 pull-right" wire:click="secondStepSubmit"
                        type="button">Next</button>
                </div>
            @endif

            <!-- Step 3 -->
            @if ($currentStep == 3)
                <div>
                    <h3>Step 3</h3>
                    <x-label for="form_password" value="Password Uji" />
                    <x-input wire:model="form.password" id="form_password" type="password" class="w-full mt-1" required
                        autocomplete="new-password" />
                    <x-input-error for="form.password" class="text-sm text-danger mt-1" />

                    <button class="btn btn-danger mt-3 pull-right" wire:click="back(2)" type="button">Back</button>
                    <button class="btn btn-success mt-3 pull-right" wire:click="submitForm"
                        type="button">Finish!</button>
                </div>
            @endif
        </x-slot>

        <x-slot name="footer">
            <x-secondary-button @click="$wire.set('modalUjiCreate', false)" wire:loading.attr="disabled">
                Tutup
            </x-secondary-button>
        </x-slot>
    </x-dialog-modal>
</div>
