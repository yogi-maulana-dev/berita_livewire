<div>
    <x-dialog-modal wire:model="modalUjiEdit">
        <x-slot name="title">
            Edit Uji - Wizard Form
        </x-slot>

        <x-slot name="content">
            <div class="stepwizard">
                <div class="stepwizard-row setup-panel">
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 1 ? 'btn-primary' : 'btn-default' }}"
                            disabled>1</button>
                        <p>Step 1</p>
                    </div>
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 2 ? 'btn-primary' : 'btn-default' }}"
                            disabled>2</button>
                        <p>Step 2</p>
                    </div>
                    <div class="stepwizard-step">
                        <button type="button"
                            class="btn btn-circle {{ $currentStep == 3 ? 'btn-primary' : 'btn-default' }}"
                            disabled>3</button>
                        <p>Step 3</p>
                    </div>
                </div>
            </div>

            @if ($currentStep == 1)
                <div>
                    <h3>Step 1</h3>
                    <x-label for="form_name" value="Name" />
                    <x-input wire:model="form.name" id="form_name" type="text" class="w-full mt-1" />
                    <x-input-error for="form.name" class="text-sm text-danger mt-1" />

                    <button class="btn btn-primary mt-3 pull-right" wire:click="nextStep">Next</button>
                </div>
            @endif

            @if ($currentStep == 2)
                <div>
                    <h3>Step 2</h3>
                    <x-label for="form_email" value="Email" />
                    <x-input wire:model="form.email" id="form_email" type="email" class="w-full mt-1" />
                    <x-input-error for="form.email" class="text-sm text-danger mt-1" />

                    <button class="btn btn-danger mt-3 pull-right" wire:click="previousStep">Back</button>
                    <button class="btn btn-primary mt-3 pull-right" wire:click="nextStep">Next</button>
                </div>
            @endif

            @if ($currentStep == 3)
                <div>
                    <h3>Step 3</h3>
                    <x-label for="form_password" value="Password" />
                    <x-input wire:model="form.password" id="form_password" :type="$showPassword ? 'text' : 'password'" class="w-full mt-1" />
                    <x-input-error for="form.password" class="text-sm text-danger mt-1" />

                    <button class="btn btn-secondary mt-3" wire:click="togglePasswordVisibility">
                        {{ $showPassword ? 'Hide' : 'Show' }} Password
                    </button>

                    <button class="btn btn-danger mt-3 pull-right" wire:click="previousStep">Back</button>
                    <button class="btn btn-success mt-3 pull-right" wire:click="edit">Finish</button>
                </div>
            @endif
        </x-slot>

        <x-slot name="footer">
            <x-secondary-button @click="$wire.set('modalUjiEdit', false)">
                Tutup
            </x-secondary-button>
        </x-slot>
    </x-dialog-modal>
</div>
