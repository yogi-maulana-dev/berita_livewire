<div>
    {{-- Do your work, then step back. --}}

    {{--  <table class="w-full mt-2">
        <thead>
            <tr>
                <th class="p-2 border whitespace-nowrap border-spacing-1">No</th>

                </th>
                <th class="p-2 border whitespace-nowrap border-spacing-1">Aksi</th>
            </tr>
            <tr>
            <tr>
                <td></td>

            </tr>
            </tr>
        </thead>
        <tbody>

            @isset($data)
                @foreach ($data as $uji)
                    <tr>
                        <td class="p-2 text-center border border-spacing-1">{{ $loop->iteration }}</td>
                        <td class="p-2 border border-spacing-1">{{ $uji->name }}</td>
                        <td class="p-2 border border-spacing-1">
                            <x-button type="button"
                                @click="$dispatch('dispatch-uji-table-edit', {id: {{ $uji->id }}})">Edit</x-button>
                            <x-danger-button
                                wire:click="$dispatch('dispatch-uji-table-hapus', { id: {{ $uji->id }}, name: '{{ $uji->name }}' })">
                                Hapus
                            </x-danger-button>
                        </td>
                    </tr>
                @endforeach
            @endisset

            <tr>
                <td class="p-2 text-center border border-spacing-1"></td>
                <td class="p-2 border border-spacing-1"></td>
                <td class="p-2 border border-spacing-1">

                </td>
            </tr>

        </tbody>
    </table>  --}}
    <div class="w-full mt-2" wire:init="$refresh">
        <livewire:user-table />
    </div>
</div>
