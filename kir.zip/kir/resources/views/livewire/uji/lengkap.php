<div>
    <x-modal wire:model="modalUjiCreate">
        <x-slot name="title">
            Formulir Pendaftaran Uji Kendaraan
        </x-slot>

        <x-slot name="content">
            @if ($successMessage)
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                    role="alert">
                    {{ $successMessage }}
                </div>
            @endif

            <form wire:submit.prevent="submitForm">
                {{-- Step 1: Identitas Pemilik --}}
                @if ($currentStep == 1)
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <x-label for="nama_pemilik">Nama Pemilik</x-label>
                            <x-input wire:model="form.identitas_pemilik.nama_pemilik" type="text" id="nama_pemilik"
                                placeholder="Masukkan nama pemilik" />
                            @error('form.identitas_pemilik.nama_pemilik')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label for="nomor_kartu">Nomor Kartu</x-label>
                            <x-input wire:model="form.identitas_pemilik.nomor_kartu" type="text" id="nomor_kartu"
                                placeholder="Masukkan nomor kartu" />
                            @error('form.identitas_pemilik.nomor_kartu')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="col-span-2">
                            <x-label for="alamat">Alamat</x-label>
                            <x-textarea wire:model="form.identitas_pemilik.alamat" id="alamat"
                                placeholder="Masukkan alamat lengkap" />
                            @error('form.identitas_pemilik.alamat')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label for="nomor_rfid">Nomor RFID</x-label>
                            <x-input wire:model="form.identitas_pemilik.nomor_rfid" type="text" id="nomor_rfid"
                                placeholder="Masukkan nomor RFID" />
                            @error('form.identitas_pemilik.nomor_rfid')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="col-span-2 flex justify-end">
                            <x-button wire:click="firstStepSubmit" type="button">
                                Lanjut ke Foto Kendaraan
                            </x-button>
                        </div>
                    </div>
                @endif

                {{-- Step 2: Foto Kendaraan --}}
                @if ($currentStep == 2)
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <x-label>Foto Depan</x-label>
                            <x-input wire:model="form.foto_kendaraan.foto_depan" type="file" accept="image/*" />
                            @error('form.foto_kendaraan.foto_depan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label>Foto Belakang</x-label>
                            <x-input wire:model="form.foto_kendaraan.foto_belakang" type="file" accept="image/*" />
                            @error('form.foto_kendaraan.foto_belakang')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label>Foto Kanan</x-label>
                            <x-input wire:model="form.foto_kendaraan.foto_kanan" type="file" accept="image/*" />
                            @error('form.foto_kendaraan.foto_kanan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label>Foto Kiri</x-label>
                            <x-input wire:model="form.foto_kendaraan.foto_kiri" type="file" accept="image/*" />
                            @error('form.foto_kendaraan.foto_kiri')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="col-span-2 flex justify-between">
                            <x-button wire:click="back(1)" type="button" color="secondary">
                                Kembali
                            </x-button>
                            <x-button wire:click="secondStepSubmit" type="button">
                                Lanjut ke Spesifikasi Teknis
                            </x-button>
                        </div>
                    </div>
                @endif

                {{-- Step 3: Spesifikasi Teknis --}}
                @if ($currentStep == 3)
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <x-label for="jenis_kendaraan">Jenis Kendaraan</x-label>
                            <x-select wire:model="form.spesifikasi_teknis.jenis_kendaraan" id="jenis_kendaraan">
                                <option value="">Pilih Jenis Kendaraan</option>
                                <option value="mobil">Mobil</option>
                                <option value="motor">Motor</option>
                                <option value="truk">Truk</option>
                                <option value="bus">Bus</option>
                            </x-select>
                            @error('form.spesifikasi_teknis.jenis_kendaraan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label for="merk">Merk</x-label>
                            <x-input wire:model="form.spesifikasi_teknis.merk" type="text" id="merk"
                                placeholder="Masukkan merk kendaraan" />
                            @error('form.spesifikasi_teknis.merk')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label for="tipe_kendaraan">Tipe Kendaraan</x-label>
                            <x-input wire:model="form.spesifikasi_teknis.tipe_kendaraan" type="text"
                                id="tipe_kendaraan" placeholder="Masukkan tipe kendaraan" />
                            @error('form.spesifikasi_teknis.tipe_kendaraan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label for="tahun_perakitan">Tahun Perakitan</x-label>
                            <x-input wire:model="form.spesifikasi_teknis.tahun_perakitan" type="number"
                                id="tahun_perakitan" min="1900" max="{{ date('Y') }}"
                                placeholder="Masukkan tahun perakitan" />
                            @error('form.spesifikasi_teknis.tahun_perakitan')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label for="bahan_bakar">Bahan Bakar</x-label>
                            <x-select wire:model="form.spesifikasi_teknis.bahan_bakar" id="bahan_bakar">
                                <option value="">Pilih Bahan Bakar</option>
                                <option value="bensin">Bensin</option>
                                <option value="solar">Solar</option>
                                <option value="listrik">Listrik</option>
                                <option value="hybrid">Hybrid</option>
                            </x-select>
                            @error('form.spesifikasi_teknis.bahan_bakar')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="col-span-2 flex justify-between">
                            <x-button wire:click="back(2)" type="button" color="secondary">
                                Kembali
                            </x-button>
                            <x-button wire:click="thirdStepSubmit" type="button">
                                Lanjut ke Hasil Uji
                            </x-button>
                        </div>
                    </div>
                @endif

                {{-- Step 4: Hasil Uji --}}
                @if ($currentStep == 4)
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <x-label for="rem_utama">Rem Utama (%)</x-label>
                            <x-input wire:model="form.hasil_uji.rem_utama" type="number" id="rem_utama"
                                min="0" max="100" placeholder="Masukkan persentase rem utama" />
                            @error('form.hasil_uji.rem_utama')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <x-label for="hasil_uji">Hasil Uji</x-label>
                            <x-select wire:model="form.keterangan_hasil_uji.hasil_uji" id="hasil_uji">
                                <option value="">Pilih Hasil Uji</option>
                                <option value="lulus">Lulus</option>
                                <option value="tidak_lulus">Tidak Lulus</option>
                            </x-select>
                            @error('form.keterangan_hasil_uji.hasil_uji')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="col-span-2">
                            <x-label>Tambahan Detail Pengujian (Opsional)</x-label>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <x-label for="nama_petugas">Nama Petugas Penguji</x-label>
                                    <x-input wire:model="form.keterangan_hasil_uji.nama_petugas_penguji"
                                        type="text" id="nama_petugas" placeholder="Nama petugas" />
                                </div>
                                <div>
                                    <x-label for="masa_berlaku">Masa Berlaku Uji</x-label>
                                    <x-input wire:model="form.keterangan_hasil_uji.masa_berlaku_uji_berkala"
                                        type="date" id="masa_berlaku" />
                                </div>
                            </div>
                        </div>

                        <div class="col-span-2 flex justify-between">
                            <x-button wire:click="back(3)" type="button" color="secondary">
                                Kembali
                            </x-button>
                            <x-button type="submit">
                                Simpan Data Uji
                            </x-button>
                        </div>
                    </div>
                @endif
            </form>
        </x-slot>
    </x-modal>

    {{-- Tombol Buka Modal --}}
    <x-button wire:click="$set('modalUjiCreate', true)">
        Buat Pengujian Baru
    </x-button>
</div>
