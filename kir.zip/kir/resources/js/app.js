// import "./bootstrap";

// resources/js/app.js

import "./../../vendor/power-components/livewire-powergrid/dist/bootstrap5.css";
// resources/js/app.js

import "./../../vendor/power-components/livewire-powergrid/dist/powergrid";

import flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";

import Toastify from "toastify-js";

window.Toastify = Toastify;
