import { defineConfig } from "vite";
import laravel from "laravel-vite-plugin";

export default defineConfig({
    server: {
        host: "192.168.100.161",
        port: 5173,
    },
    plugins: [
        laravel({
            input: [
                "resources/js/jquery1-3.4.1.min.js",
                "resources/js/popper1.min.js",
                "resources/js/bootstrap1.min.js",
                "resources/vendors/count_up/jquery.waypoints.min.js",
                "resources/vendors/chartlist/Chart.min.js",
                "resources/vendors/count_up/jquery.counterup.min.js",
                "resources/vendors/niceselect/js/jquery.nice-select.min.js",
                "resources/vendors/owl_carousel/js/owl.carousel.min.js",
                "resources/vendors/datatable/js/buttons.flash.min.js",
                "resources/vendors/datatable/js/pdfmake.min.js",
                "resources/vendors/datatable/js/vfs_fonts.js",
                "resources/vendors/progressbar/jquery.barfiller.js",
                "resources/vendors/tagsinput/tagsinput.js",
                "resources/vendors/scroll/scrollable-custom.js",
                "resources/vendors/chart_am/core.js",
                "resources/vendors/chart_am/charts.js",
                "resources/vendors/chart_am/animated.js",
                "resources/vendors/chart_am/kelly.js",
                "resources/vendors/scroll/perfect-scrollbar.min.js",
                "resources/js/chart.min.js",
                "resources/js/custom.js",
            ],
            refresh: true,
        }),
    ],
});
