<?php

use App\Http\Controllers\AuthenticationController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::middleware('auth:sanctum')->group(function () {
    Route::get('/users', [UserController::class, 'index']);
    Route::get('/users/{id}', [UserController::class, 'show']);

    Route::post('/logout', [AuthenticationController::class, 'logout']);

    Route::get('/me', [AuthenticationController::class, 'me']);


    Route::patch('/user/{id}', [AuthenticationController::class, 'update']);
    Route::delete('/user/{id}', [AuthenticationController::class, 'destroy']);
});

Route::post('/user/daftar', action: [AuthenticationController::class, 'store']);

Route::post('/login', [AuthenticationController::class, 'login']);